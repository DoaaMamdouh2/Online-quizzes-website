<div class="fixed-header">
    <div class="container">
        <nav>
            <a href="#"><?php echo $_SESSION['first_name'] .' '. $_SESSION['last_name']; ?> </a>
            <a href="index.php" style="padding-left: 104px;">Home</a>
            <a href="start_quiz.php" style="margin-left: -12px;">Choose Quiz</a>
            <a href="logout.php" style="margin-left: 35%;">Logout</a>
        </nav>
    </div>
</div>